import requests
from time import sleep
from datetime import datetime,timedelta,time
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib
from datetime import date

def sendEmail(email,title):
  emaildata = MIMEMultipart()
  emaildata["from"]="gst"
  emaildata["to"]=email
  emaildata["subject"]="Test"
  emaildata.attach(MIMEText(f"<h1>Hello There!</h1><p>This is to inform you that your task {title} is pending!</p>","html"))
  smtp = smtplib.SMTP(host="smtp.gmail.com",port=587)
  smtp.ehlo()
  smtp.starttls()
  smtp.login("todoworkmanagement@gmail.com","todo45678")
  smtp.send_message(emaildata)
  smtp.close()
  print("Sent")


def runner():
  data = requests.get("https://workmanagementapp.gocool123.repl.co/api/")
  for i in data.json():
    print(i)
    if(not i["isCompleted"]):
      date_time_obj = datetime.strptime(i["created"].replace("T"," ").split(".")[0], '%Y-%m-%d %H:%M:%S')
      today = date.today()
      t = time(hour=17, minute=00)
      final = (datetime.combine(today, t))
      if(date_time_obj.date() == final.date()):
        sendEmail(i["userName"],i["title"])

while(True):
  today = date.today()
  t = time(hour=17, minute=00)
  final = (datetime.combine(today, t)).strftime("%Y-%m-%d %H:%M")
  now = (datetime.now().strftime("%Y-%m-%d %H:%M"))
  print(now)
  if(now==final):
    runner()
  sleep(60*1)


  